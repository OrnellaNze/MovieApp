﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using My_Movies_App.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace My_Movies_App.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MoviesDbContext _context;

        public HomeController(ILogger<HomeController> logger,MoviesDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public ViewResult Index()
        {
            int hour = DateTime.Now.Hour;
            ViewBag.Greeting = hour < 12 ? "Good Morning" : "Good evening";
            //Sending movies to the view
            var Movies = _context.Movies.ToList(); 
            return View(Movies);
        }


        [HttpPost]
        [Authorize]
        public async Task<ViewResult> WatchForm(int Id, string Title, DateTime Now, string Email)
        {
            var watch = new Watch() { MovieId=Id, Email=Email, Title=Title, WatchedTime=Now };
            try
            {
                var w = _context.Watch.Find(Id);
                if (w == null)
                {
                    _context.Watch.Add(watch);
                    await _context.SaveChangesAsync();

                }
                // Todo: Store guest response,
                return View("View", watch);
            }
            catch(Exception ex)
            {

            }
            return View();

        }
        public ViewResult watchForm(int id)
        {
            var Movie = _context.Movies.FirstOrDefault(x => x.Id == id);
            return View(Movie);
        }


        public ViewResult WatchedList()
        {
            var Movie = _context.Watch.Where(w=>w.Email==User.Identity.Name);
            return View(Movie);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
