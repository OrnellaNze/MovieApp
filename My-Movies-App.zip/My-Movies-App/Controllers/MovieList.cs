﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace My_Movies_App.Controllers
{
    public class MovieList : Controller
    {
        // GET: MovieList
        public ActionResult Index()
        {
            return View();
        }

        // GET: MovieList/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: MovieList/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MovieList/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: MovieList/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: MovieList/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: MovieList/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: MovieList/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
