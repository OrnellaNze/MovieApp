﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using My_Movies_App.Models;

#nullable disable

namespace My_Movies_App.Models
{
    public partial class MoviesDbContext : DbContext
    {
        

        public MoviesDbContext(DbContextOptions<MoviesDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Movie> Movies { get; set; }


       
       

        public DbSet<My_Movies_App.Models.Watch> Watch { get; set; }
    }
}
