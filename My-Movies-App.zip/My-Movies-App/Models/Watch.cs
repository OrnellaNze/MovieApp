﻿using System;
using System.ComponentModel.DataAnnotations;

namespace My_Movies_App.Models
{
    public class Watch
    {
       
           
        [Key]
        public int WatchID { get; set; }
            public int MovieId { get; set; }
            public string Title { get; set; }
       
        public DateTime WatchedTime { get; set; }
            public string Email { get; set; }
        

        }
    }


