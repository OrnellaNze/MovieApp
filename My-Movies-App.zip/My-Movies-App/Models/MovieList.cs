﻿using System;

namespace My_Movies_App.Models
{
    public class MovieList
    {
        public int MovieId { get; set; }
        public string Title { get; set; }
        public DateTime DateTime { get; set; }
        public string Email { get; set; }
    }
}
